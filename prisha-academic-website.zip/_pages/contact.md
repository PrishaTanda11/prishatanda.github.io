---
layout: page
title: "Contact"
permalink: /contact/
---

Feel free to reach out!

- 📧 Email: [prishatanda08@gmail.com](mailto:prishatanda08@gmail.com)
- 🔗 [LinkedIn](https://linkedin.com/in/prishatanda11)
