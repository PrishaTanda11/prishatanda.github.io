---
layout: page
title: "Research"
permalink: /research/
---

## Key Research Projects

### Chromatin Dynamics – ENS Lyon
- BIOSANTEX internship program in France.
- Engineered yeast strains and analyzed chromosome condensation.

### Nanotherapeutics – INST Mohali
- Synthesized and characterized drug-delivery nanoparticles.

### Tumor Microenvironment – ACTREC, Mumbai
- Molecular techniques on cancer cell lines and tumor environment.

### Environmental Electromicrobiology – IISER Mohali
- Biofuel and bioremediation potential of electroactive microbes.
