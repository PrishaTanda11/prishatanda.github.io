---
layout: page
title: "Curriculum Vitae"
permalink: /cv/
---

## Education
- **BS-MS Dual Degree**, Indian Institute of Science Education and Research, Mohali (2025) — CGPA: 8.1/10  
- **High School**, CBSE (2020) — 86%

## Research Experience

### Chromatin Dynamics and Chromosome Architecture Lab – ENS Lyon, France
* Investigated the link between DNA replication and chromosome condensation using fission yeast.
* Techniques: yeast strain engineering, fluorescence microscopy, Western blotting, FACS.

### Nanotherapeutics Lab – INST Mohali
* Developed HSA nanoparticles for drug delivery to neuroblastoma cells.
* Techniques: TEM, DLS, UV-Vis, cell culture.

### Diabetic Vascular Complications Lab – IISER Mohali
* Studied lncRNAs involved in wound healing under diabetic conditions.
* Tools: UCSC Genome Browser, GTEx.

(Visit the Research page for more)
