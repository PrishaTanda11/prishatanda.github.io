---
layout: page
title: "Skills"
permalink: /skills/
---

## Laboratory Techniques
- **Molecular Biology:** PCR, Western Blotting, Cloning, RNA/DNA Isolation
- **Microscopy:** Fluorescence, Chromosome Spreading
- **Bioinformatics:** UCSC Genome Browser, GTEx, Galaxy
- **Spectroscopy:** UV-Vis, TEM, DLS, Zeta Potential
