---
layout: home
title: "Prisha Tanda"
subtitle: "Master Graduate from Indian Institute of Science Education, Mohali, India"
---

Welcome to my academic website. I am passionate about molecular biology, interdisciplinary research, and scientific communication.
This site showcases my research experience, technical skills, and academic journey.
